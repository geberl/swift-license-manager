//
//  CocoaFob.h
//  CocoaFob
//
//  Created by Gleb Dolgich on 05/07/2015.
//  Copyright © 2015 PixelEspresso. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for CocoaFob.
FOUNDATION_EXPORT double CocoaFobVersionNumber;

//! Project version string for CocoaFob.
FOUNDATION_EXPORT const unsigned char CocoaFobVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CocoaFob/PublicHeader.h>


